#!/bin/bash

set -e

echo "==> Creating folder structure..."
mkdir -p src/utils/handlers
mkdir -p src/utils

echo "==> Writing core files..."
cat > src/config.ts <<'EOF'
// Copy the config.ts contents provided earlier here
EOF

cat > src/utils/isFreshWallet.ts <<'EOF'
// Copy the isFreshWallet.ts contents provided earlier here
EOF

cat > src/utils/handlers/sniperooHandler.ts <<'EOF'
// Copy the sniperooHandler.ts contents provided earlier here
EOF

cat > src/autoBuySell.ts <<'EOF'
// Copy the autoBuySell.ts contents provided earlier here
EOF

cat > src/exchangeMonitor.ts <<'EOF'
// Copy the exchangeMonitor.ts contents provided earlier here
EOF

cat > src/index.ts <<'EOF'
// Copy the index.ts contents provided earlier here
EOF

cat > README.md <<'EOF'
# Solana Exchange Fresh Wallet Tracker Bot

## Features

- Configurable list of exchange Solana addresses (Binance, OKX, etc).
- Monitors outgoing SOL transfers from those exchanges.
- If a recipient is a fresh wallet, bot tracks it.
- If a fresh wallet buys a new SPL token, bot auto-buys/sells using Sniperoo API.
- Chain tracking: If the fresh wallet sends to another fresh wallet, the process repeats.

## Setup

1. **Set your exchange addresses** in `src/config.ts` under `exchanges`.
2. **Set your Sniperoo API key and pubkey** in `.env`: